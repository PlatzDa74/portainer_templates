# Ansible GitLab Artifact App

This project is designed to automate the process of uploading files to a GitLab repository, waiting for the CI/CD pipeline to complete, and deploying the resulting artifacts to a target system. It leverages Ansible playbooks and roles to streamline these tasks.

## Project Structure

```
ansible-gitlab-artifact-app
├── playbooks
│   ├── upload_files.yml         # Playbook to upload files to GitLab
│   ├── wait_for_pipeline.yml     # Playbook to wait for GitLab CI/CD pipeline completion
│   └── deploy_artifacts.yml      # Playbook to deploy artifacts to target system
├── roles
│   ├── upload_to_repo           # Role for uploading files to GitLab
│   │   ├── tasks
│   │   │   └── main.yml         # Tasks for uploading files
│   │   └── README.md            # Documentation for upload_to_repo role
│   ├── wait_for_artifacts       # Role for waiting on pipeline artifacts
│   │   ├── tasks
│   │   │   └── main.yml         # Tasks for waiting on artifacts
│   │   └── README.md            # Documentation for wait_for_artifacts role
│   └── deploy_to_target         # Role for deploying artifacts
│       ├── tasks
│       │   └── main.yml         # Tasks for deploying artifacts
│       └── README.md            # Documentation for deploy_to_target role
├── group_vars
│   └── all.yml                  # Variables for all hosts
├── inventory                     # Inventory of target systems
├── requirements.yml              # Required Ansible roles and collections
└── README.md                    # Documentation for the entire project
```

## Usage

1. **Setup**: Ensure you have Ansible installed and the necessary roles defined in `requirements.yml`.
2. **Configuration**: Update `group_vars/all.yml` with your GitLab repository details and target system information.
3. **Execution**:
   - Use `upload_files.yml` to upload files to the GitLab repository.
   - Run `wait_for_pipeline.yml` to monitor the pipeline status.
   - Finally, execute `deploy_artifacts.yml` to copy the artifacts to the target system.

---

## Nutzung mit Ansible Tower (AWX) und Survey Form

Um dieses Projekt im Ansible Tower (AWX) zu verwenden und Variablen wie `gitlab_repo`, den GitLab-Hostnamen sowie das Zielsystem dynamisch zu setzen, empfiehlt sich die Nutzung einer Survey Form:

1. **Job Template anlegen:**  
   Erstelle im Ansible Tower ein neues Job Template und wähle das passende Playbook aus.

2. **Survey aktivieren:**  
   Wechsle im Template auf den Tab **Survey** und klicke auf **Add**.

3. **Survey-Felder anlegen:**  
   Lege für jede benötigte Variable (z.B. `gitlab_repo`, `gitlab_host`, `target_host`) ein Feld an. Gib jeweils einen Variablennamen an, der im Playbook verwendet wird.

4. **Survey speichern:**  
   Speichere die Survey. Beim Starten des Jobs erscheint das Formular und die Werte werden als `extra_vars` an das Playbook übergeben.

5. **Verwendung im Playbook:**  
   Die Variablen können im Playbook wie folgt verwendet werden:
   ```yaml
   - name: Beispiel-Task
     debug:
       msg: "Repo: {{ gitlab_repo }}, Host: {{ gitlab_host }}, Ziel: {{ target_host }}"
   ```

**Weitere Informationen:**  
[Offizielle Dokumentation zu Surveys](https://docs.ansible.com/automation-controller/latest/html/userguide/surveys.html)

---

## Requirements

- Ansible 2.9 or higher
- Access to a GitLab repository with CI/CD configured
- Proper permissions to deploy to the target system

## Contributing

Feel free to submit issues or pull requests to enhance the functionality of this project.