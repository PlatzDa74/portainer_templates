# README for the upload_to_repo Role

This role is responsible for uploading one or more files to a specified GitLab repository. It is designed to be used within an Ansible playbook that facilitates the automation of file management and deployment processes.

## Requirements

- Ansible 2.9 or higher
- GitLab API access with appropriate permissions to push files to the repository

## Variables

This role requires the following variables to be defined in your playbook or inventory:

- `gitlab_repo`: The URL of the GitLab repository where files will be uploaded.
- `gitlab_token`: The personal access token for authenticating with the GitLab API.
- `files_to_upload`: A list of file paths that need to be uploaded to the repository.

## Example Usage

Here is an example of how to use this role in a playbook:

```yaml
- name: Upload files to GitLab repository
  hosts: localhost
  roles:
    - upload_to_repo
  vars:
    gitlab_repo: "https://gitlab.com/yourusername/yourrepo.git"
    gitlab_token: "your_access_token"
    files_to_upload:
      - "/path/to/file1.txt"
      - "/path/to/file2.txt"
```

## License

This role is licensed under the MIT License. See the LICENSE file for more details.

## Author Information

This role was created in 2023 by [Your Name].